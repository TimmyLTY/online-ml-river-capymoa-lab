Online Machine Learning with River and CapyMOA
Tianyi LIANG - ENSTA Paris

Overleaf: New Project > Upload Project > select this ZIP.
Main document: main.tex. Compiler: pdfLaTeX.
All tables, figures and references are included; no Python or external paths needed.
Edit main.tex to revise the report. Compile twice to resolve references.
Local build: pdflatex main.tex (twice).
